#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from User import Member, Librarian
from Catalog import Catalog

#creating users
user1 = Member("shyam","bangalore",22,"zxcc8765","std123")
user2 = Member("manikanta","bangalore",23,"zxcc5765","std143")

#creating a librarian
lib1 = Librarian("admin","banglore",23,"12345678","569")

#adding book and book items
book = lib1.addBook("money heist","abc",2001,500)
lib1.addBookItem(book,"12abc","h101")
lib1.addBookItem(book,"13abc","h102")
lib1.addBookItem(book,"14abc","h103")
lib1.addBookItem(book,"15abc","h104")

book = lib1.addBook("rich dad ","pqr",2005,300)
lib1.addBookItem(book,"12def","g101")
lib1.addBookItem(book,"13def","g102")
lib1.addBookItem(book,"14def","g103")
lib1.addBookItem(book,"15def","g104")

book = lib1.addBook("ford vs ferrari","xyz",2016,350)
lib1.addBookItem(book,"12pqr","h101")
lib1.addBookItem(book,"13pqr","s102")

lib1.displayBooks()#displaying the inventory
print("\n\n")

#issuing the books
user1.issueBook("money heist")
user2.issueBook("rich dad ")
user1.issueBook("ford vs ferrari")
print("books inventory after issued by members")
lib1.displayBooks()
print("\n\n")

#returning the books
print("books inventry after returning the books by user1 and user2")
user1.returnBook("money heist")
user2.returnBook("ford vs ferrari")
lib1.displayBooks()


